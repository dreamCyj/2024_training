1. 将start.sh和squarerootapi-1.0-SNAPSHOT.zip 上传到linux环境中(虚拟机/opt目录下)
2. 执行命令 ./start.sh squarerootapi-1.0-SNAPSHOT.zip
3. 虚拟机内打开浏览器 输入localhost:9001 即可访问 主机访问虚拟机IP:9001 例192.168.200.130：9001
